# Cloud_Attendance_System
Cloud based student attendance system

Architecture
---------------

![alt text](https://github.com/kujalk/Cloud_Attendance_System/blob/main/cloud2.PNG)

Extra Notes
---------------
https://scripting4ever.wordpress.com/2021/03/23/different-views-based-on-users-privileges-in-django-application/


Developer - K.Janarthanan
